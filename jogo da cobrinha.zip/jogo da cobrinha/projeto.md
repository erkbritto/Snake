🎮 Desafio de Desenvolvimento de Computação Gráfica - 01 🎮
Projeto: Jogo da Cobrinha 🐍✨
Autor: Erick De Britto Carvalho

RA: G78HED3

Turma: CC5P13

Período: Noturno

🌟 Visão Geral do Projeto
Neste desafio, o objetivo foi recriar o clássico Jogo da Cobrinha utilizando Python e a biblioteca Pygame. O jogo apresenta uma interface gráfica simples, movimentação fluida, detecção de colisões, geração de comida e um sistema de pontuação. A cobra cresce ao comer a comida, e o jogo termina ao colidir com as bordas ou consigo mesma. 

🚀 Etapas do Desenvolvimento
Pesquisa de Bibliotecas 📚
Escolhi Pygame por sua facilidade em criar jogos 2D e suporte a gráficos e eventos.
Configuração do Ambiente ⚙️
Instalei o Pygame com: pip install pygame.
Criação da Janela 🖼️
Janela de 600x600 pixels com título "Jogo da Cobrinha - Erick G78HED3".
Design da Cobra 🐍
Representada por uma lista de posições (vetores) desenhadas como quadrados verdes.
Movimentação ➡️⬅️⬆️⬇️
Controlada pelas setas do teclado, com movimento contínuo na direção escolhida.
Comida 🍎
Quadrado vermelho gerado aleatoriamente na grade.
Detecção de Colisão 🚨
Verifica colisões com bordas e o próprio corpo da cobra.
Pontuação ⭐
Aumenta ao comer comida e é exibida na tela.
Game Over 🎬
Ativado por colisões, com mensagem final e pontuação.
Testes ✅
Joguei várias vezes para garantir funcionamento perfeito!
🎨 Design e Estilo
Cores:
Fundo: Preto 🖤
Cobra: Verde 💚
Comida: Vermelho ❤️
Texto: Branco 🤍
Estilo: Minimalista e funcional.
Feedback: Mensagem de "Game Over" com pontuação final.

Pré-requisitos:
Python 3.6 ou superior instalado.
Instale as dependências com: pip install -r requirements.txt.
Como Jogar:

Salve o código em snake.py.
Execute com: python snake.py.
Use as setas do teclado (⬆️⬇️⬅️➡️) para mover a cobra.
Objetivo: Coma a comida vermelha e evite colisões!

Game Over:
O jogo termina ao colidir com as bordas ou consigo mesma.

📑 Estrutura do Projeto
snake.py: Código principal do jogo.
documentacao.pdf: Arquivo com informações do autor e instruções.



Jogo da Cobrinha
Autor: Erick De Britto Carvalho
RA: G78HED3
Turma: CC5P13
Período: Noturno

Instruções:
1. Instale as dependências: pip install pip install pygame
2. Execute: python snake.py
3. Controles: Setas do teclado
4. Objetivo: Coma a comida e evite colisões!
🌟 Dicas para o Sucesso
Teste Bem: Jogue várias vezes para verificar bugs.
Personalize: Ajuste a velocidade ou cores no código se quiser!

🎉 Considerações Finais
Este projeto foi desenvolvido com muito cuidado para atender ao desafio e impressionar! O código é claro, o jogo é divertido e tudo está bem documentado.