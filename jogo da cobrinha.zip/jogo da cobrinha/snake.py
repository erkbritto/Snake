import pygame
import random
import sys
from pygame import mixer

# Inicializa o Pygame
pygame.init()
mixer.init()

# Configurações da janela
larguraJanela = 600
alturaJanela = 600
tamanhoBloco = 20
janela = pygame.display.set_mode((larguraJanela, alturaJanela))
pygame.display.set_caption("Snake Adventure")

# Carrega imagens (substitua pelos caminhos reais das imagens)
try:
    cobra_cabeca_img = pygame.transform.scale(pygame.image.load("snake_head.png"), (tamanhoBloco, tamanhoBloco))
    maca_img = pygame.transform.scale(pygame.image.load("apple.png"), (tamanhoBloco, tamanhoBloco))
except FileNotFoundError:
    print("Imagens não encontradas, usando formas geométricas")
    cobra_cabeca_img = None
    maca_img = None

# Carrega sons com tratamento de erro
comer_som = None
game_over_som = None
try:
    comer_som = mixer.Sound("eat.wav")
    game_over_som = mixer.Sound("gameover.wav")
except FileNotFoundError:
    print("Arquivos de som não encontrados, continuando sem áudio")

# Cores
corFundo = (34, 139, 34)  # Verde floresta
corTexto = (255, 255, 255)
corBorda = (139, 69, 19)  # Marrom terra

# Configurações iniciais
posicaoCobra = [[300, 300]]
direcaoCobra = [0, 0]
velocidade = 8
clock = pygame.time.Clock()
fonte = pygame.font.SysFont("pixel", 30, bold=True)
fonte_titulo = pygame.font.SysFont("pixel", 50, bold=True)

# Comida
posicaoComida = [random.randrange(0, larguraJanela, tamanhoBloco), 
                random.randrange(0, alturaJanela, tamanhoBloco)]
pontuacao = 0

def desenharCobra():
    for i, posicao in enumerate(posicaoCobra):
        if i == 0 and cobra_cabeca_img:
            cabeca_rot = cobra_cabeca_img
            if direcaoCobra == [tamanhoBloco, 0]:  # Direita
                cabeca_rot = pygame.transform.rotate(cobra_cabeca_img, 0)
            elif direcaoCobra == [-tamanhoBloco, 0]:  # Esquerda
                cabeca_rot = pygame.transform.rotate(cobra_cabeca_img, 180)
            elif direcaoCobra == [0, -tamanhoBloco]:  # Cima
                cabeca_rot = pygame.transform.rotate(cobra_cabeca_img, 90)
            elif direcaoCobra == [0, tamanhoBloco]:  # Baixo
                cabeca_rot = pygame.transform.rotate(cobra_cabeca_img, -90)
            janela.blit(cabeca_rot, (posicao[0], posicao[1]))
        else:
            # Calcula a cor com base no índice do bloco (gradiente HSL)
            hue = (i * 15) % 360  # Varia o matiz (hue) para cada bloco
            cor = pygame.Color(0, 0, 0)  # Inicializa a cor
            cor.hsla = (hue, 100, 50, 100)  # Matiz, Saturação, Luminosidade, Alfa
            pygame.draw.rect(janela, cor, [posicao[0], posicao[1], tamanhoBloco, tamanhoBloco], border_radius=5)

def desenharComida():
    if maca_img:
        janela.blit(maca_img, (posicaoComida[0], posicaoComida[1]))
    else:
        pygame.draw.circle(janela, (255, 0, 0), 
                         (posicaoComida[0] + tamanhoBloco//2, posicaoComida[1] + tamanhoBloco//2), 
                         tamanhoBloco//2)

def moverCobra():
    novaPosicao = [posicaoCobra[0][0] + direcaoCobra[0], posicaoCobra[0][1] + direcaoCobra[1]]
    posicaoCobra.insert(0, novaPosicao)
    if novaPosicao != posicaoComida:
        posicaoCobra.pop()
    else:
        pegarComida()

def pegarComida():
    global posicaoComida, pontuacao
    pontuacao += 1
    if comer_som:
        comer_som.play()
    posicaoComida = [random.randrange(0, larguraJanela, tamanhoBloco), 
                    random.randrange(0, alturaJanela, tamanhoBloco)]

def verificarColisao():
    cabeca = posicaoCobra[0]
    return (cabeca[0] < 0 or cabeca[0] >= larguraJanela or 
            cabeca[1] < 0 or cabeca[1] >= alturaJanela)

def exibirHUD():
    score = fonte.render(f"Score: {pontuacao}", True, corTexto)
    janela.blit(score, (10, 10))
    
    pygame.draw.rect(janela, (139, 69, 19), (10, 40, 100, 10))
    energia = min(pontuacao * 5, 100)
    pygame.draw.rect(janela, (0, 255, 0), (10, 40, energia, 10))

def telaInicio():
    janela.fill(corFundo)
    titulo = fonte_titulo.render("Snake Adventure", True, corTexto)
    instrucao = fonte.render("Pressione ESPAÇO para começar", True, corTexto)
    janela.blit(titulo, (larguraJanela//2 - titulo.get_width()//2, alturaJanela//2 - 50))
    janela.blit(instrucao, (larguraJanela//2 - instrucao.get_width()//2, alturaJanela//2 + 20))
    pygame.display.flip()
    esperar = True
    while esperar:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.KEYDOWN and evento.key == pygame.K_SPACE:
                esperar = False

def telaGameOver():
    if game_over_som:
        game_over_som.play()
    janela.fill(corFundo)
    texto = fonte_titulo.render("Game Over!", True, corTexto)
    pont = fonte.render(f"Pontuação: {pontuacao}", True, corTexto)
    reiniciar = fonte.render("R - Reiniciar | Q - Sair", True, corTexto)
    janela.blit(texto, (larguraJanela//2 - texto.get_width()//2, alturaJanela//2 - 60))
    janela.blit(pont, (larguraJanela//2 - pont.get_width()//2, alturaJanela//2))
    janela.blit(reiniciar, (larguraJanela//2 - reiniciar.get_width()//2, alturaJanela//2 + 40))
    pygame.display.flip()

def reiniciarJogo():
    global posicaoCobra, direcaoCobra, pontuacao, posicaoComida
    posicaoCobra = [[300, 300]]
    direcaoCobra = [0, 0]
    pontuacao = 0
    posicaoComida = [random.randrange(0, larguraJanela, tamanhoBloco), 
                    random.randrange(0, alturaJanela, tamanhoBloco)]

def main():
    global direcaoCobra
    telaInicio()
    rodando = True
    
    while rodando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_UP:
                    direcaoCobra = [0, -tamanhoBloco]
                elif evento.key == pygame.K_DOWN:
                    direcaoCobra = [0, tamanhoBloco]
                elif evento.key == pygame.K_LEFT:
                    direcaoCobra = [-tamanhoBloco, 0]
                elif evento.key == pygame.K_RIGHT:
                    direcaoCobra = [tamanhoBloco, 0]

        if direcaoCobra != [0, 0]:
            moverCobra()

        janela.fill(corFundo)
        pygame.draw.rect(janela, corBorda, (0, 0, larguraJanela, alturaJanela), 5)
        
        desenharCobra()
        desenharComida()
        exibirHUD()

        if verificarColisao():
            telaGameOver()
            esperando = True
            while esperando:
                for evento in pygame.event.get():
                    if evento.type == pygame.QUIT:
                        rodando = False
                        esperando = False
                    elif evento.type == pygame.KEYDOWN:
                        if evento.key == pygame.K_r:
                            reiniciarJogo()
                            esperando = False
                        elif evento.key == pygame.K_q:
                            rodando = False
                            esperando = False

        pygame.display.update()
        clock.tick(velocidade)

    pygame.quit()

if __name__ == "__main__":
    main()